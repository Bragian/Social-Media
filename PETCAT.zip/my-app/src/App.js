import { Routes, Route, Outlet, Link } from "react-router-dom";
import CatPerez from "./Components/View/CatPerez";
import Home from './Components/View/Home';
import Login from "./Components/View/Login";
import Profile from "./Components/View/Profile";

function App() {
  return (
    <div className="App container">

      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/Home" element={<Home />} />
        <Route path="/CatPerez" element={<CatPerez />} />
        <Route path="/FormProfile" element={<Profile />}/>
      </Routes>

    </div>

  );
}

export default App;
