
import React from 'react';

export default function ContentADS() {
    return (
     <div className="col-2">
      <h6>Publicidad</h6>
     <div className='ads'><img className="img-fluid" src='/images/ads/1.jpg'/></div>
     <div className='ads'><img className="img-fluid" src='/images/ads/2.jpg'/></div>
     <div className='ads'><img className="img-fluid" src='/images/ads/3.jpg'/></div>
     <div className='ads'><img className="img-fluid" src='/images/ads/4.jpg'/></div>
     </div>
    );
  }
  