
import React from 'react';
import ContentPost from './Post/ContentPost';
import ContentADS from './ADS/ContentADS';
import ContentProfile from './Profile/ContentProfile';

export default function Content() {
    return (
    <>
   <div className="content-social">
   <div className="row">
   
    <ContentProfile/>
    <ContentPost/>
    <ContentADS/>

 
   </div>
   </div>
    </>
    );
  }
 

