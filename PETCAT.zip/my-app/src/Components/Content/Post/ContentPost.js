
import React from 'react';
import Post from './Post';


export default function ContentPost() {
    return (
      
     <div className="col-8 pad-content-post">
     <div className="row">
     <Post/>
     </div>
     </div>
   
    );
  }
  