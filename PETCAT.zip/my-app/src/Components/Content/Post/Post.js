
import React from 'react';
import CommentButton from '../../Buttons/CommentButton';
import SharedButton from '../../Buttons/SharedButton';
import LikeButton from '../../Buttons/LikeButton';
import Data from '../../data.json';


export default function Post() {
 
    return (
  
<>
    {
    Data.map(data => { 
      return(
        <div className="col-6 nopadding pad-post">
        <div className="content-post">
        
        <img className="img-fluid" src={data.imagen}/>
    
       <div className="box-post">
       <div className="detail-post">    
       <div className="date"> {data.fecha}</div>
       <div className="copy">{data.copy}</div> 
       </div>
       <div className="reactions-box">
    
       <ul className="reactions-ul">
       <li className="reactions-li"><LikeButton/></li>
       <li className="reactions-li"><CommentButton/></li>
       <li className="reactions-li"><SharedButton/></li>
       </ul>
       </div>
       </div>
       
       </div>
       </div>
      )
    })
    }



</>
    );
  }
  