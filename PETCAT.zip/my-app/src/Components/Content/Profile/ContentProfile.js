
import React from 'react';
import Fullname from '../Profile/Fullname';
import Friends from '../Profile/Friends';
import Groups from './Groups';
import Photo from './Photo';

export default function ContentProfile() {
    return (
    <>
    <div className='col-2'> 
    <div className="content-perfil">
    <Photo />
    <Fullname/>
    <hr/>
    <Friends />
    <hr/>
    <Groups/>
    </div>
    </div>
    </>
    );
  }
  