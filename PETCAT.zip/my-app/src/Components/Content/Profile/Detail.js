

import React from 'react';


export default function Detail() {
    return (
    <>
    <div className="caracts">
    <h6>Edad: 11 meses</h6>
    <h6>Peso: 2.5kg</h6>
    <h6>Color: Gris</h6>
    </div>
    </>
    );
  }
 


