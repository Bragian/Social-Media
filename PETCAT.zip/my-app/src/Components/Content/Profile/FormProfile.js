
import React from 'react';
import FormProfile from '../View/Profile';
import Header from '../ElementHtml/Header';


export default function FormProfile() {
    return (
    
    <>

   <Header/>
   <FormProfile/>

    </>
    );
  }
  