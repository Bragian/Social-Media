

import React from 'react';


export default function Friends() {
    return (
    <>
   <h6 className="nameperfil">MIS AMIGOS</h6>
     <hr/>
     <div className="box-friends row">
     <div className="col-6 nopadding"><div className="img-friends"><img className="img-fluid" src='images/friends/f1.jpg'/></div></div>
     <div className="col-6 nopadding"><div className="img-friends"><img className="img-fluid" src='images/friends/f2.jpg'/></div></div>
     <div className="col-6 nopadding"><div className="img-friends"><img className="img-fluid" src='images/friends/f3.jpg'/></div></div>
     <div className="col-6 nopadding"><div className="img-friends"><img className="img-fluid" src='images/friends/f4.jpg'/></div></div>
     <div className="col-6 nopadding"><div className="img-friends"><img className="img-fluid" src='images/friends/f5.jpg'/></div></div>
     <div className="col-6 nopadding allfriends"><b>VER TODOS</b></div>
     </div>
    </>
    );
  }
 


