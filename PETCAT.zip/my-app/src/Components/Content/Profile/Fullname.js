

import React from 'react';


export default function Fullname() {
    return (
    <>
    <h6 className="nameperfil">CAT PEREZ</h6>
    </>
    );
  }
 


