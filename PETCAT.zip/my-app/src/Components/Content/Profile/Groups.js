
import React from 'react';


export default function Groups() {
    return (
    <>
     <h6 className="nameperfil">MIS GRUPOS</h6>
     <hr/>
     <h6 className="descripperfil">Soy un gatito travieso, me gusta las croquetas, y el baño con agua tibia.</h6>
    </>
    );
  }
 


