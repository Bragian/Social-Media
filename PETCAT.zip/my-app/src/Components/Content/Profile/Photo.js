
import React from 'react';


export default function Photo() {
    return (
    <>
        <a href="\CatPerez"><img className="img-fluid perfil-photo" src='images/perfil.jpg'/></a>
    </>
    );
  }
 


