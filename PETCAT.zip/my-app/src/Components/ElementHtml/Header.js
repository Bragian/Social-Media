
import React from 'react';


export default function Header() {
    return (
    <>
<div className="bg-pets">
     <nav className="navbar navbar-light row">
     <div className="container-fluid">

     <a className="col-2" href='\Home'>
    
     <img className="logo" src='images/petslogo.webp' width={125}/>

    </a>

    <form className="d-flex col-8">
      <input className="form-control" type="search" placeholder="Buscar amigos cerca..." aria-label="Search" />
    </form>

    <div className="col-2">
    <a href="\FormProfile">
    <div className="profile-content">
    <img className="" src='images/pata-min.png' />
    <div className="title-profile"> Ver perfil</div>
    </div>
    </a>
    
    </div>
    
    </div>
    </nav>
   
    </div>
     


    </>
    );
  }
 

