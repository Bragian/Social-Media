
import React from 'react';
import Fullname from '../Content/Profile/Fullname';
import AboutMe from '../Content/Profile/AboutMe';
import Detail from '../Content/Profile/Detail';
import Header from '../ElementHtml/Header';
import ContentPost from '../Content/Post/ContentPost';
import ContentADS from '../Content/ADS/ContentADS';
import Friends from '../Content/Profile/Friends';
import Photo from '../Content/Profile/Photo';


export default function CatPerez() {
    return (
    <>
    
    <Header />
   
    <div className="content-social">
    <div className="row">
   
    <div className='col-2'> 
    <div className="content-perfil">
    <Photo />
    <Fullname/>
    <hr/>
    <Detail/>
    <hr />
    <AboutMe />
    <hr/>
    <Friends />
    </div>
    </div>

    <ContentPost/>
    <ContentADS />

    </div>
    </div>
  

    </>
    );
  }
  