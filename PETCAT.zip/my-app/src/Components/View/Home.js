
import React from 'react';
import Content from '../Content/Content';
import Header from '../ElementHtml/Header';

export default function Home() {
    return (
    <>
    
    <Header />
    <Content/>
    

    </>
    );
  }
  