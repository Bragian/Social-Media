
import React from 'react';

export default function Login() {
    return (



<div className="login-content" style={{ backgroundImage: "url(./images/background.png)" }}>
<div className="Logo-login">
<img className="img-fluid img-detector" src='/images/petslogo.webp'/>
<div className="Logo-title">SONRÍE A LA CÁMARA</div>
</div>

<form className="row col-3 form-login" action="/Home">
  <img className="img-fluid img-detector" src='/images/detector.gif'/>
  <div className="Logo-title">O INGRESE DATITOS</div>
  <div className="col-12">
    <input type="text" className="form-control" id="inputAddress" placeholder="USUARIO" />
  </div>
  <div className="col-12">
    <input type="text" className="form-control box-form" id="inputAddress2" placeholder="CONTRASEÑA" />
  </div>

  <div className="col-12">
    <button type="submit" className="btn btn-primary col-12 box-form button-form button-submit">INGRESAR</button>
  </div>
</form>
</div>

    );
  }
  