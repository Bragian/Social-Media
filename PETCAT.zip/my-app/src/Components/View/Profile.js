
import React from 'react';
import Header from '../ElementHtml/Header';


export default function Profile() {
    return (
    
  <>
  <Header/>
  <div className="content-social">
  <div className="row">
  <div className='col-12'>
  <div className='col-8 center-col'>
  <div className="row">

  <div className='col-6'>
  <div className="title-form">EDITAR PERFIL</div>
  <div className="img-profile-form">
  <img className="img-fluid" src='images/perfil.jpg'/>
  <div className="mb-3">
  <input className="form-control box-form" type="file" id="formFile" />
  </div>
  </div>
  </div>
  
  <div className='col-6'>

  <div className="col-12">
  <input type="text" className="form-control" placeholder="Ingrese su usuario" value="CAT2023" />
  </div>

  <div className="col-12">
  <input type="password" className="form-control box-form" placeholder="Ingrese su contreseña" value="12345678" />
  </div>

  <div className="col-12">
  <input type="text" className="form-control box-form" placeholder="Ingrese su nombre" value="CAT" />
  </div>

  <div className="col-12">
  <input type="text" className="form-control box-form"placeholder="Ingrese su apellido" value="PEREZ" />
  </div>

  <div className="col-12">

  <select className="form-select box-form" aria-label="Default select example">
  <option selected>¿Qué soy?</option>
  <option value="1">Gato</option>
  <option value="2">Hamnster</option>
  <option value="3">Perro</option>
  </select>

  </div>

  <div className="col-12">
  <input type="date" className="form-control box-form"placeholder="Ingrese su nacimiento" value="09/11/1995" />
  </div>

  <div className="col-12">
  <input type="text" className="form-control box-form"placeholder="Ingrese su peso" value="2.5kg" />
  </div>

  <div className="col-12">
  <input type="text" className="form-control box-form" placeholder="Ingrese su color" value="Gris" />
  </div>

  <div className="col-12">
  <textarea className="form-control box-form" placeholder="Escribe acerca de ti" value="Soy un gatito travieso, me gustan las croquetas y el baño con agua tibia."></textarea>
  </div>

  <div className="col-12">
  <button type="submit" className="btn btn-primary col-12 box-form button-form button-submit">GUARDAR</button>
  </div>
  
  </div>

  </div>
  </div>
  </div>

  </div>
  </div>
  </>
    );
  }
  